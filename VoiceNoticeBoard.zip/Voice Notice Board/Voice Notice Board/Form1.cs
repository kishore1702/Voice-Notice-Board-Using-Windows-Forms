﻿    using System;
    using System.Speech.Recognition;
    using System.Speech.Synthesis;
    using System.Windows.Forms;

    namespace Voice_Notice_Board
    {
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
            }

            public void label1_Click(object sender, EventArgs e)
            {

            }
            SpeechSynthesizer speechSynthesizerObj;
            public void Form1_Load(object sender, EventArgs e)
            {
            
            
                    speechSynthesizerObj = new SpeechSynthesizer();
                    speechSynthesizerObj.SpeakAsync("Please speak");
                    SpeechRecognitionEngine sRecognize = new SpeechRecognitionEngine();
                    Choices sList = new Choices();
                //you can add more messages and sentences in here to speak out while the program runs.
                    sList.Add(new string[] {"Hello", "Good Morning", "Hai", "Bye","Good Night"});
                    Grammar gr = new Grammar(new GrammarBuilder(sList));
                    try
                    {
                        sRecognize.RequestRecognizerUpdate();
                        sRecognize.LoadGrammar(gr);
                        sRecognize.SpeechRecognized += sRecognize_SpeechRecognized;
                        sRecognize.SetInputToDefaultAudioDevice();
                        sRecognize.RecognizeAsync(RecognizeMode.Multiple);
                        sRecognize.Recognize();
                    }
                    catch
                    {
                        return;
                    }
                }

            public void sRecognize_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
            {
                label1.Text = e.Result.Text;
            }
        }
    }
